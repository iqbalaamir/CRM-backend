const express = require('express');
const router = express.Router();

const contactController = require('../controllers/contact.controller');
const {authJwt} = require('../middlewares/index');

router.get('/', [authJwt.isAdminOrManager], contactController.getContacts);
router.post('/create', [authJwt.isAdminOrManager], contactController.createContact);
router.get('/:id', [authJwt.isAdminOrManager], contactController.getContactById);
router.put('/update/:id', [authJwt.isAdminOrManager], contactController.updateContact);
router.delete('/delete/:id', [authJwt.isAdminOrManager], contactController.deleteContact);



module.exports  = router;