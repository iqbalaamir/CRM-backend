// Index.js

const express = require('express');
const router = express.Router();
const leadeRoute = require('./leads.route');

const defaultRoutes = [
    {
        path: '/leads',
        route: leadeRoute,
    }
];
defaultRoutes.forEach((route) => {
    router.use(route.path, route.route);
});
module.exports = router;